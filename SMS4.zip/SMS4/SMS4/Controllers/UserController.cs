﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SMS4.Models;
using SMS4.Controllers;
using System.Data.SqlClient;

namespace SMS4.Controllers
{
    class UserController
    {
        

        internal void login(string email, string password)
        {
            SmsDbContext studentDb = new SmsDbContext();

            SqlParameter p1 = new SqlParameter();
            SqlParameter p2 = new SqlParameter();

            p1.ParameterName = "@Email";
            p1.Value = email;
            p1.SqlDbType = System.Data.SqlDbType.VarChar;
            p2.ParameterName = "@Password";
            p2.Value = password;
            p2.SqlDbType = System.Data.SqlDbType.VarChar;

            var students = studentDb.Students.ToList();
            Student stud = new Student();
            foreach (Student s in students)
            {
                if (s.email == email && s.password == password) stud = s;

            }


            if (stud != null)
            {
                if (stud.role == "Student")
                {
                    Console.WriteLine("Login Successfully... !!!");
                    Console.WriteLine("==========================================");
                    Console.WriteLine("*****  Student Role  *****");
                    Console.WriteLine("------------------------------------------");
                    StudentController sc = new StudentController();
                    sc.StudentRole();
                }
                else if (stud.role == "Admin")
                {
                    Console.WriteLine("Admin Role");
                    AdminController.AdminRole();
                }
                else Console.WriteLine("Invalid UserName & Password...User Not Found !!!");
            }
            else Console.WriteLine("User Not Found !!!");

        }

        internal void register(string studentName, string studentEmail, string studentPassword, string course, string gender, int mob_number, string address)
        {

            SmsDbContext ctx = new SmsDbContext();
            Student stud = new Student();
            stud.name = studentName;
            stud.email = studentEmail;
            stud.password = studentPassword;
            stud.gender = gender;
            stud.mob_number = mob_number;
            stud.address = address;
            stud.role = "Student";
            stud.course = course;

            ctx.Students.Add(stud);
            ctx.SaveChanges();

            Console.WriteLine("Registered Successfully... !!!");

            Console.WriteLine("==========================================");
        }

    }
}
