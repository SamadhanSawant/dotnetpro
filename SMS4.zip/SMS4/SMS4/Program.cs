﻿using System;
using SMS4.Controllers;
using SMS4.Models;

namespace SMS4
{
    class Program
    {
        static void Main(string[] args)
        {

        startpoint:
            Console.Clear();
            Console.WriteLine("==========================================");
            Console.WriteLine("----- Welcome to SMS by DotNet Group 10 ! -------");
            Console.WriteLine("==========================================");
            while (true)
            {
                Console.WriteLine(" 1-Login \n 2-Registration");
                Console.WriteLine("==========================================");

                String Selected_1 = Console.ReadLine();

                UserController user = new UserController();

                switch (Selected_1)
                {
                    case "1":
                        Console.WriteLine("*****  Login  *****");
                        Console.WriteLine("------------------------------------------");
                        Console.Write("Email : ");
                        String email = Console.ReadLine();
                        Console.Write("Password : ");
                        Console.ForegroundColor = ConsoleColor.Black;
                        String password = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Write("Cofirm Password : ");
                        Console.ForegroundColor = ConsoleColor.Black;
                        String password1= Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.White;

                        if (password == "" || password1 == "")
                        {
                            Console.WriteLine("------------------------------------------");
                            Console.WriteLine("Password Matched");
                            Console.WriteLine("------------------------------------------");
                            return;
                        }
                        else if (password != password1)
                        {
                            Console.WriteLine("------------------------------------------");
                            Console.WriteLine("Password Doesnt Match !!!");
                            Console.WriteLine("------------------------------------------");
                            return;
                        }

                        Console.WriteLine("==========================================");

                      //  Console.WriteLine("Logged in !!!");

                        user.login(email, password);

                        break;

                    case "2":
                        Console.WriteLine("*****  Student Registration  *****");
                        Console.WriteLine("------------------------------------------");
                        Console.Write("Name : ");
                        String studentName = Console.ReadLine();
                        Console.Write("Email : ");
                        String studentEmail = Console.ReadLine();
                        Console.Write("Password : ");
                        Console.ForegroundColor = ConsoleColor.Black;
                        String studentPassword = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.White;

                        Console.Write("Confirm Password : ");
                        Console.ForegroundColor = ConsoleColor.Black;
                        String studentPassword1 = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.White;

                        if (studentPassword == "" || studentPassword1 == "")
                        {
                            Console.WriteLine("------------------------------------------");
                            Console.WriteLine("Password Matched");
                            Console.WriteLine("------------------------------------------");
                            return;
                        }
                        else if (studentPassword  != studentPassword1)
                        {
                            Console.WriteLine("------------------------------------------");
                            Console.WriteLine( "Password Doesnt Match !!!");
                            Console.WriteLine("------------------------------------------");
                            return;
                        }

                        Console.Write("Gender : ");
                        String gender = Console.ReadLine();
                        Console.Write("Address : ");
                        String address = Console.ReadLine();
                        Console.Write("Mobile Number : ");
                        int mob_number = (int)Convert.ToInt64( Console.ReadLine());


                        Console.Write("Course : ");
                        String course = Console.ReadLine();
                       
                        Console.WriteLine("==========================================");

                       // Console.WriteLine("Registered !!!");

                       user.register(studentName, studentEmail, studentPassword,gender,address,mob_number ,course);

                        break;

                    default:
                        Console.WriteLine("Wrong Choice!!!");
                        break;
                }
            }


        }
    }
}

