﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS4.Models
{
    public class Student
    {
        [Key]
        public int userID { get; set; }

        [Column("Name")]
        [Required(ErrorMessage = "Please enter the Name")]
        [MaxLength(15)]
        public string name { get; set; }

        [Column("Email")]
        [Required(ErrorMessage = "Please enter the Email ID")]
        [MaxLength(20)]
        public string email { get; set; }

        [Column("Password")]
        [Required(ErrorMessage = "Please Enter the Password")]
        [MaxLength(12)]
        public string password { get; set; }

        [Column("Gender")]
        [Required(ErrorMessage = "Please Enter the Gender")]
        [MaxLength(12)]
        public string gender { get; set; }

        [Column("Address")]
        [Required(ErrorMessage = "Please Enter the Address")]
        [MaxLength(12)]
        public string address { get; set; }

       

        [Column("Mob_Number")]
        [Required(ErrorMessage = "Please Enter the Mobile Number")]
        [MaxLength(12)]
        public int mob_number{ get; set; }


        [Column("Role")]
        [Required(ErrorMessage = "Please Enter your Role")]
        public string role { get; set; }

        [Column("Course")]
        [Required(ErrorMessage = "Please Enter your Course")]
        public string course { get; set; }

       


    }
}
