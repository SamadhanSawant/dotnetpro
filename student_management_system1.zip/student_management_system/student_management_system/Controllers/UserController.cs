﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using student_management_system.Models;
using System.Security.Cryptography;
using student_Management_System.DataBaseContext;
using System.Text.RegularExpressions;

namespace student_management_system.Controllers
{
    class UserController
    {
        private const string SecurityKey = "ComplexKeyHere_12121";
        public void userLogin()
        {
            Console.WriteLine("-------User's Login -------");
            Console.Write("Email : ");
            String email = Console.ReadLine();
            Console.Write("Password : ");
            String password = Console.ReadLine();
            //String studentPassword = (Console.ReadLine());
            //  Console.ForegroundColor = ConsoleColor.Black;

            //   Console.ForegroundColor = ConsoleColor.White;
            //Console.Write("Cofirm Password : ");
            //  Console.ForegroundColor = ConsoleColor.Black;
            // String studentPassword1 = Console.ReadLine();
            // Console.ForegroundColor = ConsoleColor.White;



            /* if (studentPassword == "" || studentPassword1 == "")
             {
                 Console.WriteLine("------------------------------------------");
                 Console.WriteLine("Password Matched!!!");
                 Console.WriteLine("------------------------------------------");
                 return;
             }
             else if (studentPassword != studentPassword1)
             {
                 Console.WriteLine("------------------------------------------");
                 Console.WriteLine("Password Doesnt Match !!!");
                 Console.WriteLine("------------------------------------------");
                 return;
             }
             Console.WriteLine("---------------------------");*/


            SmsDbContext dbctx = new SmsDbContext();
            List<User> userList = dbctx.Users.ToList();
            User searchedUser = new User();

            foreach (User u in userList)
            {
                if (u.email == email && u.password == password)
                    searchedUser = u;
            }

            if (searchedUser != null)
            {
                if (searchedUser.role == "Student")
                {
                    StudentController studentControl = new StudentController();
                    studentControl.StudentRole();
                }
                else if (searchedUser.role == "Admin")
                {
                    AdminController.AdminRole();
                }
                else Console.WriteLine("Invalid Credentials !!!");
            }
            else Console.WriteLine("User Not Found !!!");

        }

        public void userRegistration()
        {
            Console.WriteLine("------- Student's Registration ------");
      
            Console.Write("Name : ");
            String studentName = Console.ReadLine();
            Console.Write("Email : ");
            String studentEmail = Console.ReadLine();
            Console.Write("Password : ");
            String studentPassword = (Console.ReadLine());
            Console.Write("Please Enter the Mobile Number : ");
            String studentMobileNumber = Console.ReadLine();
            Console.Write("Please Enter the Gender : ");
            String studentGender = Console.ReadLine();
            Console.Write("Please Enter the Address : ");
            String studnetAddress = Console.ReadLine();
            Console.Write("Please Enter the Date of Birth in Format of MM/DD/YYYY : ");
            String studentDOB = (Console.ReadLine());
            Console.Write("Course : ");
            String course = Console.ReadLine();
            Console.WriteLine("-------------------------------------");


            SmsDbContext ctx = new SmsDbContext();

            Student stud = new Student();
            User user = new User();

            user.name = studentName;
            user.email = studentEmail;
            user.password = studentPassword;
            user.Gender = studentGender;
            user.MobileNumber = studentMobileNumber;
            user.Address = studnetAddress;
            user.DOB = Convert.ToDateTime(studentDOB);
            Console.WriteLine(" Mention Your Role: \n1)Student\n2)Teacher\n3)Admin");
            switch (Convert.ToInt32(Console.ReadLine()))
            {
                case 1:
                    user.role = "Student";
                    break;
                case 2:
                    user.role = "Teacher";
                    break;
                case 3:
                    user.role = "Admin";
                    break;
                default:
                    Console.WriteLine("Please give appropriate option") ;
                    break;

            }
            // user.role = "Student";

            stud.course = course;
            user.student = stud;

            ctx.Users.Add(user);
            ctx.Students.Add(stud);
            ctx.SaveChanges();


            Console.WriteLine("-----------------------------");
            Console.WriteLine(studentName + " registered !!!");
            Console.WriteLine("-----------------------------");
        }

    }

}


