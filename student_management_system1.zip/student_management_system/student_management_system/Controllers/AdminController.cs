﻿
using student_management_system.Models;
using student_Management_System.DataBaseContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace student_management_system.Controllers
{
    class AdminController
    {
        public static void AdminRole()
        {
            Console.WriteLine("-----------------------------");
            Console.WriteLine(" Welcome Admin !!!");
            Console.WriteLine(" You've Logged in as a Admin !");
            Boolean flag = true;
            while (flag)
            {
                Console.WriteLine("-----------------------------");


                Console.WriteLine("1-Add_Student\n2-Delete_Student\n3-Update_Student\n4-Show_All_Students\n5-Logout");
                Console.WriteLine("-----------------------------");

                int option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        addStudent();
                        break;

                    case 2:
                        deleteStudent();
                        break;

                    case 3:
                        updateStudent();
                        break;

                    case 4:
                        showAll();
                        break;

                    case 5:
                        Console.WriteLine("Logout !!!");
                        Console.WriteLine("==============================");
                        flag = false;
                        break;

                }
            }
        }

        private static void showAll()
        {
            Console.WriteLine("--------- All Users Data ---------");

            SmsDbContext ctx = new SmsDbContext();
            List<User> usrs = ctx.Users.ToList();
            List<Student> stds = ctx.Students.ToList();

            foreach (User u in usrs)
            {
                foreach (Student s in stds)
                {
                    if (u.userID == s.studentId)
                        Console.WriteLine($"{u.userID}{s.studentId} {u.name} {u.email}{u.MobileNumber}{u.Gender}{u.Address}{u.DOB}{s.course}");
                }

            }

            Console.WriteLine("----------------------------------");
        }

        private static void updateStudent()
        {
            Console.WriteLine("------ Update Student ------");
            Console.Write("Enter ID :");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.Write("New Name : ");
            String newName = Console.ReadLine();
            Console.Write("New Email : ");
            String newEmail = Console.ReadLine();
            Console.Write("New Password : ");
            String newPassword = Console.ReadLine();
            Console.Write("New Course :");
            String newCourse = Console.ReadLine();
            Console.Write("New Mobile Number : ");
            String newMobileNumber = Console.ReadLine();
            Console.Write("New Address : ");
            String newAddress = Console.ReadLine();
            Console.Write("New Gender :");
            String newGender = Console.ReadLine();
            Console.Write("New Date Of Birth : ");
            String newDOB = Console.ReadLine();

            SmsDbContext ctx = new();
            User usr = ctx.Users.Find(id);
            Student stud = ctx.Students.Find(id);

            usr.name = newName;
            usr.email = newEmail;
            usr.password = newPassword;
            usr.DOB = Convert.ToDateTime(newDOB);
            usr.Address = newAddress;
            usr.Gender = newGender;
            usr.MobileNumber = newMobileNumber;
            stud.course = newCourse;


            ctx.Students.Update(stud);
            ctx.Users.Update(usr);
            ctx.SaveChanges();

            Console.WriteLine("------------------------");
            Console.WriteLine(usr.name + " updated !!!!");
            Console.WriteLine("------------------------");
        }

        private static void deleteStudent()
        {
            Console.WriteLine("------ Delete Student ------");
            Console.WriteLine("Enter ID :");
            int id = Convert.ToInt32(Console.ReadLine());

            SmsDbContext ctx = new();
            User usr = ctx.Users.Find(id);
            Student stud = ctx.Students.Find(id);

            ctx.Users.Remove(usr);
            ctx.Students.Remove(stud);
            ctx.SaveChanges();

            Console.WriteLine("-----------------------------");
            Console.WriteLine(usr.name + "  Student  Deleted  ");
            Console.WriteLine("-----------------------------");
        }

        private static void addStudent()
        {
            Console.WriteLine("------- Add Student ------");
            Console.Write("Name : ");
            String studentName = Console.ReadLine();
            Console.Write("Email : ");
            String studentEmail = Console.ReadLine();
            Console.Write("Password : ");
            String studentPassword = Console.ReadLine();
            Console.Write("Course : ");
            String course = Console.ReadLine();
            Console.Write("Mobile Number : ");
            String newMobileNumber = Console.ReadLine();
            Console.Write("Address :");
            String newAddress = Console.ReadLine();
            Console.Write("Gender : ");
            String newGender = Console.ReadLine();
            Console.Write("Date Of Birth : ");
            String newDOB = Console.ReadLine();


            SmsDbContext ctx = new SmsDbContext();

            Student stud = new Student();
            User user = new User();

            user.name = studentName;
            user.email = studentEmail;
            user.password = studentPassword;
            user.DOB = Convert.ToDateTime(newDOB);
            user.Address = newAddress;
            user.Gender = newGender;
            user.MobileNumber = newMobileNumber;
            user.role = "Student";
            user.student.course = course;

            user.student = stud;
            ctx.Users.Add(user);
            ctx.Students.Add(stud);

            ctx.SaveChanges();

            Console.WriteLine("-----------------------------");
            Console.WriteLine(studentName + " Added to SMS !!!");
            Console.WriteLine("-----------------------------");
        }


        public void AddAdmin()
        {
            SmsDbContext ctx = new SmsDbContext();
            Student NA = new Student();
            User admn = new User();
            admn.name = "admin";
            admn.email = "admin@gmail.com";
            admn.password = "12345";
            admn.role = "Admin";
            admn.MobileNumber = "9867543210";
            admn.Address = "Pune";
            admn.Gender = "Male";
            admn.DOB =Convert.ToDateTime("09/13/1995");
            NA.course = "-";
            admn.student = NA;
            ctx.Users.Add(admn);
            ctx.Students.Add(NA);
            ctx.SaveChanges();
        }
    }
}
