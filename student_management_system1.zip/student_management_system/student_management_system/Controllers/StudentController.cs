﻿
using student_management_system.Models;
using student_Management_System.DataBaseContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace student_management_system.Controllers
{
    public class StudentController
    {       
          
        internal void StudentRole()
        {

            SmsDbContext ctx = new SmsDbContext();
            User user = new User();
            Console.WriteLine("-----------------------------");
            Console.WriteLine(" Welcome " + user.name + " !!!");
            Console.WriteLine(" You've Logged in as a Student !");
            Boolean flag = true;
            while (flag)
            {

                Console.WriteLine("-----------------------------");

                Console.WriteLine("1-showDetails\n2-updateDetails\n3-Logout");

                Console.WriteLine("-----------------------------");

                String option = Console.ReadLine();

                switch (option)
                {
                    case "1":
                        Console.WriteLine("Show Details");
                         showDetails(user);
                        break;

                    case "2":
                        Console.WriteLine("Update Details");
                        updateDetails(user);
                        break;

                    case "3":
                        Console.WriteLine("Logout !!!");
                        flag = false;
                        break;

                }

            }
        }


        //private void updateDetails()
        //{

        //    Console.WriteLine("------ Update Student ------");
        //    Console.Write("Enter ID : ");
        //    int id = Convert.ToInt32(Console.ReadLine());
        //    Console.Write("New Mobile Number : ");
        //    String newMobileNumber = Console.ReadLine();
        //    Console.Write("New Address : ");
        //    String newAddress = Console.ReadLine();
        //    Console.Write("New Date Of Birth : ");
        //    String newDOB = Console.ReadLine();
        //    Console.Write("New Password : ");
        //    String newPassword = Console.ReadLine();
        //    Console.Write("New Course : ");
        //    String newCourse = Console.ReadLine();
        //    SmsDbContext ctx = new();
        //    try
        //    {
        //        User usr = ctx.Users.Find(id);
        //        Student stud = ctx.Students.Find(id);
        //       // Student stud = usr.student;
        //        Console.WriteLine(stud.course);    
        //        usr.password = newPassword;
        //        usr.MobileNumber = newMobileNumber;
        //        usr.Address = newAddress;
        //        usr.DOB = Convert.ToDateTime(newDOB);

        //        stud.course = newCourse;
        //        ctx.Students.Update(stud);
        //        ctx.Users.Update(usr);
        //        ctx.SaveChanges();

        //        Console.WriteLine("------------------------");
        //        Console.WriteLine(usr.name + " updated !!!!");
        //        Console.WriteLine("------------------------");
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e.StackTrace);
        //    }


        private void showDetails(User user)
        {
            SmsDbContext smsDb = new SmsDbContext();

            Student student = smsDb.Students.Find(user.userID);

            Console.WriteLine($"{user.userID} {user.name}  {user.email} {user.MobileNumber} {user.Address} {user.Gender}  {user.DOB}  {user.role}  {user.userID} {student.studentId} {student.course}"); 

        }
        private void updateDetails(User user)
        {
            SmsDbContext dbctx = new SmsDbContext();
            Console.WriteLine("Do you want to update password ? Y/N ?");
            string input = Console.ReadLine();
            String choice = input.ToUpper();

            if (choice == "Y")
            {
                Console.Write("Please Mention Updated Password: ");
                string UpdatedPassword = Console.ReadLine();
                int Id=user.userID;
                Student student = dbctx.Students.Find(Id);
                user.password = UpdatedPassword;

               // dbctx.Students.Update(student);
                dbctx.Users.Update(user);
                dbctx.SaveChanges();


            }

            else if (choice == "N")
            {
                Console.WriteLine("Do you want to update your Mobile Number ? Y/N ?");
                //string choice2 = Console.ReadLine();
                 string input2 = Console.ReadLine();
                String choice2 = input.ToUpper();
                if (choice == "Y")
                {

                    Console.Write("Please Mention Mobile Number:");
                    string UpdatedMobileNumber = Console.ReadLine();
                    Student student = dbctx.Students.Find(user.userID);
                    student.course = UpdatedMobileNumber;
                    dbctx.Users.Update(user);
                    dbctx.SaveChanges();
                }
                else if (choice == "N")

                {
                    Console.WriteLine("Do you want to update your Address ? Y/N ?");
                    //string choice2 = Console.ReadLine();
                    string input3 = Console.ReadLine();
                    String choice3 = input.ToUpper();
                    if (choice == "Y")
                    {

                        Console.Write("Please Mention Updated Address: ");
                        string UpdatedAddress = Console.ReadLine();
                        Student student = dbctx.Students.Find(user.userID);
                        student.course = UpdatedAddress;
                        dbctx.Users.Update(user);
                        dbctx.SaveChanges();
                    }

                }
                else if (choice == "N")
                { 
                    Console.WriteLine("Do you want to update your Date Of Birth ? Y/N ?");
                    //string choice2 = Console.ReadLine();
                    string input4 = Console.ReadLine();
                    String choice4 = input.ToUpper();
                    if (choice == "Y")
                    {

                        Console.Write("Please Mention Updated Mobile Number:");
                        string UpdatedMobileNumber = Console.ReadLine();
                        Student student = dbctx.Students.Find(user.userID);
                        student.course = UpdatedMobileNumber;
                        dbctx.Users.Update(user);
                        dbctx.SaveChanges();
                    }

                }

                else if (choice == "N")
                {
                    Console.WriteLine("Do you want to update your course? Y/N?");
                    //  string choice5 = Console.ReadLine();
                    string input5 = Console.ReadLine();
                    String choice5 = input.ToUpper();
                    if (choice == "Y")
                    {

                        Console.Write("Please Mention Updated Course:");
                        string UpdatedCourse = Console.ReadLine();
                        Student student = dbctx.Students.Find(user.userID);
                        student.course = UpdatedCourse;
                        dbctx.Users.Update(user);
                        dbctx.SaveChanges();
                    }
                    else if (choice == "N")
                    {
                        Console.WriteLine("-----------------------------");
                        Console.WriteLine("thank  you!!");
                    }
                    else
                    {
                        Console.WriteLine("PLEASE ENTER CORRECT CHOICE!!");
                    }

                }

                else
                {
                    Console.WriteLine("PLEASE ENTER CORRECT CHOISE!!");
                }
                //Console.Write("Please Mention Updated Password:");
                //string UpdatedPassword = Console.ReadLine();





                //  user.password = UpdatedPassword;

                //student.course = UpdatedCourse;
                //dbctx.Students.Update(student);
                //dbctx.Users.Update(user);
                //dbctx.SaveChanges();

            }
        }

    }
}

