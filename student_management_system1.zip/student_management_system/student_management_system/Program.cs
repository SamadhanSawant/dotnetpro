﻿using student_management_system.Controllers;
using System;

namespace student_management_system
{
    class Program
    {
        static void Main(string[] args)
        {
        //AdminController admn = new AdminController();
        //admn.AddAdmin();
        startpoint:

            Console.Clear();
            Console.WriteLine("==========================================");
            Console.WriteLine("|   Welcome to SMS by project group 10   |");
            while (true)
            {
                Console.WriteLine("==========================================");
                Console.WriteLine(" 1-Login \n 2-Registration \n 0-Refresh");
                Console.WriteLine("==========================================");

                int option = Convert.ToInt32(Console.ReadLine());

                Controllers.UserController userControl = new UserController();

                switch (option)
                {
                    case 1:
                        userControl.userLogin();
                        break;

                    case 2:
                        userControl.userRegistration();
                        break;

                    case 0:
                        goto startpoint;

                    default:
                        Console.WriteLine("Wrong Choice!!!");
                        break;
                }
            }

        }
    }
}
