﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace student_management_system.Models
{
    public class Student
    {
        [Key]
        public int studentId { get; set; }
        [Column("Course")]
        [Required(ErrorMessage = "Please Enter your Course")]
        public string course { get; set; }

        [ForeignKey("userID")]
        public virtual User user { get; set; }
    }
}
