﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace student_management_system.Models
{
    public class User
    {
        [Key]
        public int userID { get; set; }

        [Column("Name")]
        [Required(ErrorMessage = "Please enter the Name")]
        [MaxLength(15)]
        public string name { get; set; }

        [Column("Email")]
        [Required(ErrorMessage = " Email ID is Required")]
        [RegularExpression(@"^[a-zA-Z0-9.! #$%&'*+/=? ^_`{|}~-]+@[a-zA-Z0-9-]+(?:\. [a-zA-Z0-9-]+)*$",
        ErrorMessage = "Email should contain Uppercase (A-Z) and lowercase (a-z) English letters,Digits (0-9),Characters ! # $ % & ' * + - / = ?,Character")]
        [MaxLength(20)]
        public string email { get; set; }

        [Column("Password")]
        [Required(ErrorMessage = "Please Enter the Password")]
        [RegularExpression(@"(?= ^.{8, 15}$)(?=.*\d)(?=.*[A - Z])(?=.*[a - z])(?!.*\s).*$",
         ErrorMessage = "Between 8 and 15 inclusive, contains atleast one digit, atleast one upper case and atleast one lower case and no whitespace.")]
        [MaxLength(15)]
    public string password { get; set; }

    [Column("Mobile Number")]
    [Required()]
    [MaxLength(15)]
    public string MobileNumber { get; set; }

    [Column("Address")]
    [MaxLength(15)]
    public string Address { get; set; }

    [Column("Gender")]
    [MaxLength(10)]
    public string Gender { get; set; }

    [Column("Date Of Birth")]
    public DateTime DOB { get; set; }

    [Column("Role")]
    [Required(ErrorMessage = "Please Enter your Role")]
    public string role { get; set; }

    public virtual Student student { get; set; }
}
    
}
