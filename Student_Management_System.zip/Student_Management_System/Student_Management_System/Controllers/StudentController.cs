﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Student_Management_System.Models;
using Student_Management_System.DataBaseContext;

namespace Student_Management_System.Controllers
{
    public class StudentController
    {
        internal void StudentRole()
        {
            Boolean flag = true;
            while (flag)
            {

            Console.WriteLine("-----------------------------");
            Console.WriteLine(" Login Successfully... !!!    ");
            Console.WriteLine("-----------------------------");

            Console.WriteLine("1-showDetails\n2-updateDetails\n3-Logout");
            
            Console.WriteLine("-----------------------------");

                int option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        Console.WriteLine("Show Details");
                       
                        showDetails();

                        break;

                    case 2:
                      
                        Console.Write("Please Enter Your ID:");
                    int ID = Convert.ToInt32(Console.ReadLine());

                        updateDetails( ID);



                        break;

                    case 3:
                        Console.WriteLine("Logout !!!");
                        flag = false;
                        break;

                }

            }
        }


        private void updateDetails(int ID)
        {
            Console.Write("Please Mention Updated Password:");
            string UpdatedPassword = Console.ReadLine();


            Console.Write("Please Mention Updated Course:");
            string UpdatedCourse = Console.ReadLine();

            SmsDbContext smstdb = new SmsDbContext();
           
            User user = smstdb.Users.Find(ID);
            Student student = smstdb.Students.Find(ID);
           user.password = UpdatedPassword;
          
            student.course = UpdatedCourse;
            smstdb.Students.Update(student);
           smstdb.Users.Update(user);
            smstdb.SaveChanges();

        }

        private void showDetails()
        {
            Console.WriteLine("sanket has to complete this task");
        }


    }

}
