﻿using Student_Management_System.DataBaseContext;
using Student_Management_System.Models;
using System;
using System.Linq;

namespace Student_Management_System.Controllers
{
    class AdminController
    {
        public static void AdminRole()
        {
            Boolean flag = true;
            while (flag)
            {
                Console.WriteLine("-----------------------------");
                Console.WriteLine("     Admin Logged In !!!     ");
                Console.WriteLine("-----------------------------");


                Console.WriteLine("1-Add_Student\n2-Delete_Student\n3-Update_Student\n4-Show_All_Students\n5-Logout");
                Console.WriteLine("-----------------------------");

                int option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        Console.WriteLine("Add Student");
                        addStudent();
                        break;

                    case 2:
                        Console.WriteLine("Delete Student");
                        deleteStudent();
                        break;

                    case 3:
                        Console.WriteLine("Update Student");
                        updateStudent();
                        break;

                    case 4:
                        Console.WriteLine("Show All Students");
                        showAll();
                        break;

                    case 5:
                        Console.WriteLine("Logout !!!");
                        flag = false;
                        break;

                }
            }
        }

        private static void showAll()
        {
            Console.WriteLine("Samiksha will work on this");
        }

        private static void updateStudent()
        {
            Console.WriteLine("Samiksha will work on this");
        }

        private static void deleteStudent()
        {
            Console.WriteLine("Sameena will work on this");
        }

        private static void addStudent()
        {
            Console.WriteLine("Sameena will work on this");
        }


        public void AddAdmin()
        {
            SmsDbContext ctx = new SmsDbContext();
            User admn = new User();
            admn.name = "admin";
            admn.email = "admin@gmail.com";
            admn.password = "12345";
            admn.role = "Admin";

            ctx.Users.Add(admn);
            ctx.SaveChanges();
        }
    }
}