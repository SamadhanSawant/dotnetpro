﻿namespace Student_Management_System.Enum
{
    public enum EQual
    {
        Bachelor , Master , PHD 
    }
}
