﻿namespace Student_Management_System.Enum
{
    public enum ECourse
    {
        ANGULAR, DOTNET, JAVA, REACT
    }
}
