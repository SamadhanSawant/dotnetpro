﻿namespace Student_Management_System.Enum
{
    public enum ERole
    {
        ADMIN, STUDENT, TEACHER
    }
}
