﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Student_Management_System.Enum;

namespace Student_Management_System.Models
{
    public class Admin
    {
        [Key, ForeignKey("UserId")]
        public int AdminId { get; set; }

        public string Name { get; set; }

        public virtual User user { get; set; }

    }

}

