﻿using System.ComponentModel.DataAnnotations;
using Student_Management_System.Enum;

namespace Student_Management_System.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }

        public ERole Role { get; set; }

        public virtual Admin admin { get; set; }

        public virtual Student student { get; set; }

        public virtual Teacher teacher { get; set; }

    }

}

