﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Student_Management_System.Enum;

namespace Student_Management_System.Models
{
    public class Course
    {
        [ForeignKey("Student")]
        public int CourseId { get; set; }

        public ECourse course { get; set; }

        public virtual Student student { get; set; }

    }

}

