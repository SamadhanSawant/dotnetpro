﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Student_Management_System.Enum;

namespace Student_Management_System.Models
{
    public class Student
    {

        [Key, ForeignKey("UserId")]
        public int StudentId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Gender { get; set; }

        public string Country { get; set; }

        public string MobileNo { get; set; }

        public virtual User user { get; set; }

        public virtual Course course1 { get; set; }

    }
}
