﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Student_Management_System.Enum;

namespace Student_Management_System.Models
{
    public class Teacher
    {
        [Key, ForeignKey("UserId")]
        public int TeacherId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public EQual Qualification { get; set; }

        public ECourse Expertise { get; set; }

        public virtual User user { get; set; }
    }
}
