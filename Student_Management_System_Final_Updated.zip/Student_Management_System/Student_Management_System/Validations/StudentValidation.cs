﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Student_Management_System.Enum;

namespace Student_Management_System.Validations
{
    class StudentValidation
    {
        public static ECourse ValidateCourse()
        {
        HERE:
            Console.Write("           Course  :  [ 1- Angular | 2- Dot Net | 3- Java | 4- React ] \n");
            Console.Write("                  >>  ");
            ECourse SelectedCourse;
            int CourseId = Convert.ToInt32(Console.ReadLine());

            switch (CourseId)
            {
                case 1: SelectedCourse = ECourse.ANGULAR; break;
                case 2: SelectedCourse = ECourse.DOTNET; break;
                case 3: SelectedCourse = ECourse.JAVA; break;
                case 4: SelectedCourse = ECourse.REACT; break;
                default:
                    Console.WriteLine("---------------------------------------------------------------------------------------------");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("                                       Wrong Choice !!! ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("---------------------------------------------------------------------------------------------");
                    goto HERE;
            }

            return SelectedCourse;
        }

        public static string ValidateCountry()
        {
        HERE:
            Console.Write("          Country  :  [ 1- India | 2- Other ] \n");
            Console.Write("                  >>  ");
            string SelectedCountry;

            switch (Convert.ToInt32(Console.ReadLine()))
            {
                case 1: SelectedCountry = "India"; break;
                case 2: SelectedCountry = "Other"; break;
                default:
                    Console.WriteLine("---------------------------------------------------------------------------------------------");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("                                      Wrong Choice !!");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("---------------------------------------------------------------------------------------------");
                    goto HERE;
            }

            return SelectedCountry;
        }

        internal static string ValidateGender()
        {
        HERE:
            Console.Write("           Gender  :  [ 1- Male | 2- Female ] \n");
            Console.Write("                  >>  ");

            switch (Console.ReadLine())
            {
                case "1": return "Male"; break;
                case "2": return "Female"; break;
                default:
                    Console.WriteLine("---------------------------------------------------------------------------------------------");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("                                      Wrong Choice !!");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("---------------------------------------------------------------------------------------------");
                    goto HERE;
            }
        }

        public static string ValidateMobileNo()
        {
        REPEAT:
            Console.Write("        Mobile No  :  ");
            string no = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(no) || no.Length<10)
            {
                Console.WriteLine("---------------------------------------------------------------------------------------------");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("                             Enter 10 digit Mobile No !!!    ");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("---------------------------------------------------------------------------------------------");
                goto REPEAT;
            }
            else
            {
                if (no.All(char.IsDigit))
                {
                    return no;
                }
                else
                {
                Console.WriteLine("---------------------------------------------------------------------------------------------");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("                             Mobile No Should Contains only Digits  !!!   ");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("---------------------------------------------------------------------------------------------");
                    goto REPEAT;
                }
            }
        }
    }
}
