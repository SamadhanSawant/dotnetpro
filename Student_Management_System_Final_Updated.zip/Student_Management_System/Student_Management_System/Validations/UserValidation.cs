﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Student_Management_System.Enum;
using Student_Management_System.Models;

namespace Student_Management_System.Validations
{
    public class UserValidation
    {
        
        public static string ValidateEmail()
        
            { 
            HERE:
            Console.Write("            Email  :  ");

            string email = Console.ReadLine();

                string pattern = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";

                if (!Regex.IsMatch(email, pattern))
                {
                Console.WriteLine("---------------------------------------------------------------------------------------------");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("                          Please enter email in correct format !!! ");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("---------------------------------------------------------------------------------------------");
                goto HERE;
                }
                else
                {
                    return email;
                }
            }

        public static string ValidatePassword()
        {
        HERE:
            Console.Write("         Password  :  ");
            string password = Console.ReadLine();

            string pattern = @"(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$";

            if (!Regex.IsMatch(password, pattern))
            {
                Console.WriteLine("-----------------------------------------------------------------------------------------------------------------------------------------------------");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("A password contains at least eight characters, including at least one number and includes both lower and uppercase letters and special characters !!! ");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("-----------------------------------------------------------------------------------------------------------------------------------------------------");
                goto HERE;
            }
        CONFIRM:
            Console.Write(" Confirm Password  :  ");
            string cpassword = Console.ReadLine();

            if (password != cpassword)
            {
                Console.WriteLine("---------------------------------------------------------------------------------------------");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("                          Password does not matched !!!   ");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("---------------------------------------------------------------------------------------------");
                goto CONFIRM;
            }
            else
            {
                return password;
            }
        }



        public static string ValidateFirstName()
        {
        REPEAT: 
            Console.Write("       First Name  :  ");
            string name = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(name) || name.Any(char.IsDigit))
            {
                Console.WriteLine("---------------------------------------------------------------------------------------------");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("                            Please enter valid name !!!    ");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("---------------------------------------------------------------------------------------------");
                goto REPEAT;
            }
            else
            {
                return name;
            }
        }

        public static string ValidateLastName()
        {
        REPEAT:
            Console.Write("        Last Name  :  ");
            string name = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(name) || name.Any(char.IsDigit))
            {
                Console.WriteLine("---------------------------------------------------------------------------------------------");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("                           Please enter valid name  !!!     ");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("---------------------------------------------------------------------------------------------");
                goto REPEAT;
            }
            else
            {
                return name;
            }
        }


    }
}
