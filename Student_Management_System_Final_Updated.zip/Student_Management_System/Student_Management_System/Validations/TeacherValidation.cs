﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Student_Management_System.Enum;

namespace Student_Management_System.Validations
{
    class TeacherValidation
    {
        public static ECourse ValidateExpertise()
        {
        HERE:
            Console.Write("        Expertise  :  [ 1- Angular | 2- Dot Net | 3- Java | 4- React ] \n");
            Console.Write("                  >>  ");

            switch (Console.ReadLine())
            {
                case "1": return ECourse.ANGULAR; break;
                case "2": return ECourse.DOTNET; break;
                case "3": return ECourse.JAVA; break;
                case "4": return ECourse.REACT; break;
                default:
                    Console.WriteLine("---------------------------------------------------------------------------------------------");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("                                 Wrong Choice !!! ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("---------------------------------------------------------------------------------------------");
                    goto HERE;
                    break;
            }
               
        }

        internal static EQual ValidateQualification()
        {
            HERE:
            Console.Write("    Qualification  :  [ 1- Bachelor's | 2- Master's | 3- PHD ] \n");
            Console.Write("                  >>  ");

            switch (Console.ReadLine())
            {
                case "1": return EQual.Bachelor; break;
                case "2": return EQual.Master; break;
                case "3": return EQual.PHD; break;
                default:
                    Console.WriteLine("---------------------------------------------------------------------------------------------");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("                                    Wrong Choice !!!  ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("---------------------------------------------------------------------------------------------");
                    goto HERE;
                    break;
            }
        }
    }
    
}
