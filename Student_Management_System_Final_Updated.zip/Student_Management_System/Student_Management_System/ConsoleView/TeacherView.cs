﻿using System;
using Student_Management_System.Models;
using Student_Management_System.Controllers;
using Student_Management_System.Validations;
using Student_Management_System.Enum;
using Student_Management_System.DataBaseContext;

namespace Student_Management_System.ConsoleView
{
    public class TeacherView
    {
        //teacher role

        public static void TeacherRole(User user)
        {
            Console.Clear();
        TOP:

            SmsDbContext ctx = new SmsDbContext();
            Teacher t = ctx.Teachers.Find(user.UserId);
            int id = user.UserId;
            Program.DisplayProjectName();
            Program.DisplayWelcome("    " + t.FirstName + "  " + t.LastName + "      ");

            Boolean Flag = true;
            while (Flag)
            {
                Console.WriteLine("====================================== Teacher Dashboard  ============================================\n");

                Console.WriteLine("    1- Show All Details       2- Update Email       3- Update Password       4- Update Expertise    \n");

                Console.WriteLine("    0- Logout     \n");

                Console.WriteLine("======================================================================================================\n");
                int updateOption = Convert.ToInt32(Console.ReadLine());
                switch (updateOption)
                {
                    case 1:
                        Console.WriteLine("=========================================   Profile   =================================================\n");
                        TeacherController.ShowDetails(user);
                        break;
                    case 2:
                        Console.Write("New Email : ");
                        string email = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(AdminController.UpdateEmail(id, email));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 3:
                        Console.Write("New Password : ");
                        string password = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(AdminController.UpdatePassword(id, password));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 4:
                        ECourse expertise = TeacherValidation.ValidateExpertise();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(TeacherController.UpdateExpertise(id, expertise));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;

                    case 0:
                        Flag = false;
                        break;
                    default:
                        Console.WriteLine("----------------------------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("                                       Wrong Choice !!!");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("----------------------------------------------------------------------------------------------------------");
                        Console.ReadLine();
                        Flag = false;
                        break;
                }
            }
        }

    }

}
