﻿using Student_Management_System.Controllers;
using Student_Management_System.Enum;
using Student_Management_System.Validations;
using Student_Management_System.Models;
using System;
using Student_Management_System;


namespace Student_Management_System.ConsoleView
{
    class UserView
    {
        //Login
        //student registration
        //teacher registration

        public static void Login()
        { 
            Console.WriteLine("--------------------------------------  User's Login  --------------------------------------------");

            string email = UserValidation.ValidateEmail();

            Console.Write("         Password  :  ");
            string password = Console.ReadLine();

            Console.WriteLine("--------------------------------------------------------------------------------------------------");
            User user = UserController.getUser(email, password);

                 if (user.Role == ERole.ADMIN)    AdminView.AdminRole(user);
            else if (user.Role == ERole.STUDENT)  StudentView.StudentRole(user); 
            else if (user.Role == ERole.TEACHER)  TeacherView.TeacherRole(user);

        }


        public static void StudentRegistration()
        {
            //Console.Write("       First Name  :  ");
            string fname = UserValidation.ValidateFirstName();
            //Console.Write("        Last Name  :  ");
            string lname = UserValidation.ValidateLastName();
            //Console.Write("            Email  :  ");
            string email = UserValidation.ValidateEmail();
            //Console.Write(" Confirm Password  :  ");
            string password = UserValidation.ValidatePassword();

            //Console.Write("           Course  :      [ 1- Angular | 2- Dot Net | 3- Java | 4- React ] \n");
            //Console.Write("                  >>  ");
            ECourse course = StudentValidation.ValidateCourse();
            //Console.Write("           Gender  :      [ 1- Male | 2- Female ] \n");
            //Console.Write("                  >>  ");
            string gender = StudentValidation.ValidateGender();
            //Console.Write("          Country  :      [ 1- India | 2- Other ] \n");
            //Console.Write("             >>  ");
            string country = StudentValidation.ValidateCountry();
            //Console.Write("        Mobile No  :  ");
            string mobile = StudentValidation.ValidateMobileNo();
       
            Console.WriteLine("-----------------------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("  "       +      UserController.RegisterStudent(fname, lname, email, password, course, gender, country, mobile)
                                                            + " is registered as Student  !!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("-----------------------------------------------------------------------------------------------");
        }


        public static void TeacherRegistration()
        {

            //Console.Write("       First Name  :  ");
            string fname = UserValidation.ValidateFirstName();
            //Console.Write("        Last Name  :  ");
            string lname = UserValidation.ValidateLastName();
            //Console.Write("            Email  :  ");
            string email = UserValidation.ValidateEmail();
            //Console.Write(" Confirm Password  :  ");
            string password = UserValidation.ValidatePassword();

            //Console.Write("    Qualification  :      [ 1- Bachelor's | 2- Master's | 3- PHD ] \n");
            //Console.Write("                  >>  ");
            EQual qual = TeacherValidation.ValidateQualification();
            //Console.Write("        Expertise  :      [ 1- Angular | 2- Dot Net | 3- Java | 4- React ] \n");
            //Console.Write("                  >>  ");
            ECourse expertise = TeacherValidation.ValidateExpertise();

            Console.WriteLine("--------------------------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("    "     +        UserController.RegisterTeacher(fname, lname, email, password, qual, expertise)
                                                    + " is registered as Teacher !!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("--------------------------------------------------------------------------------------------------");
        }



        public static void returnError(String Error)
        {
            Console.WriteLine("--------------------------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("                                 [ "+Error+" ] !!!  ");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("--------------------------------------------------------------------------------------------------");
        }
    }
} 