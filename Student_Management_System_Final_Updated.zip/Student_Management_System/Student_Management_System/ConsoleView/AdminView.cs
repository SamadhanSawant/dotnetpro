﻿using Student_Management_System.DataBaseContext;
using Student_Management_System.Models;
using Student_Management_System.Controllers;
using System;
using Student_Management_System.Enum;
using System.Collections.Generic;
using System.Linq;
using Student_Management_System.Validations;

namespace Student_Management_System.ConsoleView
{
    class AdminView
    {

        public static void AdminRole(User user)
        {
            Console.Clear();
        TOP:
            Program.DisplayProjectName();
            Program.DisplayWelcome("Admin");

            Boolean flag = true;
            while (flag)
            {
               
                Console.WriteLine("\n================================  Admin Dashboard  ===========================================\n");

                Console.WriteLine("  1- Show All Students      2- Add Student       3- Remove Student       4- Update Student    \n");

                Console.WriteLine("  5- Show All Teachers      6- Add Teacher       7- Remove Teacher       8- Update Teacher    \n");

                Console.WriteLine("  0- Logout\n");

                Console.WriteLine("==============================================================================================\n");
                Console.Write(" >> ");

                switch (Convert.ToInt32(Console.ReadLine()))
                {          
                    case 1: Console.WriteLine("------------------------------------ All  Students  Data   -------------------------------------");
                            AdminController.ShowAllStudents();
                            break;
                            
                    case 2: Console.WriteLine("--------------------------------------  Add Student --------------------------------------------\n");
                            UserView.StudentRegistration();
                            break;
                            
                    case 3: Console.WriteLine("-------------------------------------- Remove Student ----------------------------------------\n");
                            Console.Write("Student ID :");
                            int id1 = Convert.ToInt32(Console.ReadLine());
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(AdminController.DeleteStudent(id1));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;

                          
                    case 4: Console.WriteLine("-------------------------------------  Update Student -------------------------------------------\n");
                            UpdateStudentForm(); 
                            break;
                            
                    case 5: Console.WriteLine("------------------------------------- All  Teachers  Data   --------------------------------------");
                            AdminController.ShowAllTeachers();
                            break;

                           
                    case 6: Console.WriteLine("-------------------------------------  Add Teacher -----------------------------------------------\n");
                            UserView.TeacherRegistration(); 
                            break;
                   
                    case 7: Console.WriteLine("------------------------------------ Remove Teacher ----------------------------------------------\n");
                            Console.Write("Teacher ID :");
                            int id2 = Convert.ToInt32(Console.ReadLine());
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(AdminController.DeleteTeacher(id2));
                        Console.WriteLine("------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                            break;

                    case 8:
                        Console.WriteLine("------------------------------------ Remove Student --------------------------------------------\n");
                        AdminView.UpdateTeacherForm();
                        break;

                    case 0: Console.Clear();
                        Console.WriteLine("-------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("                                         Logout  !!!");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("------------------------------------------------------------------------------------------------\n");
                        flag = false;
                            break;

                    default:    Console.Clear();
                        Console.WriteLine("------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.Red;
                        UserView.returnError("                                    Wrong Choice !!!");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("------------------------------------------------------------------------------------------------\n");
                        goto TOP;
                }
            }
        }



        private static void UpdateStudentForm()
        {
            Console.Write("  Enter Student Id  :  ");
            int studId = Convert.ToInt32(Console.ReadLine());
            SmsDbContext ctx = new SmsDbContext();
            Student stud = ctx.Students.Find(studId);

            Boolean Flag2 = true;
            while (Flag2)
            {

                Console.WriteLine("            Student Name  :  " + stud.FirstName + " " + stud.LastName);
                Console.WriteLine("-----------------------------------------  Update Student  --------------------------------------------\n");

                Console.WriteLine("             1-First Name                 2-Last Name                 3-Email        \n");
                Console.WriteLine("             4-Password                   5-Course                   6-MobileNo     \n");
                Console.WriteLine("             0-Back                                                                  \n");
                Console.WriteLine("---------------------------------------------------------------------------------------------------------");

                int updateOption = Convert.ToInt32(Console.ReadLine());
                switch (updateOption)
                {
                    case 1:
                        Console.Write("New First Name :");
                        string fname = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(StudentController.UpdateFirstName(studId, fname));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 2:
                        Console.Write("New Last Name : ");
                        string lname = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(StudentController.UpdateLastName(studId, lname));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 3:
                        Console.Write("New Email : ");
                        string email = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(AdminController.UpdateEmail(studId, email));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 4:
                        Console.Write("New Password : ");
                        string password = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(AdminController.UpdatePassword(studId, password));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 5:
                        ECourse course = StudentValidation.ValidateCourse();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(StudentController.UpdateCourse(studId, course));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 6:
                        string mobile = StudentValidation.ValidateMobileNo();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(StudentController.UpdateMobileNo(studId, mobile));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 0:
                        Flag2 = false;
                        break;
                    default:
                        Console.WriteLine("---------------------------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("                                    Wrong Choice   !!!   ");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("----------------------------------------------------------------------------------------------------------");
                        Flag2 = false;
                        break;
                }
            }
        }

        private static void UpdateTeacherForm()
        {
            Console.Write("  Enter Teacher Id  :  ");
            int id = Convert.ToInt32(Console.ReadLine());
            SmsDbContext ctx = new SmsDbContext();
            Teacher t = ctx.Teachers.Find(id);

            Boolean Flag2 = true;
            while (Flag2)
            {

                Console.WriteLine("                 Teacher Name  :  " + t.FirstName + " " + t.LastName);
                Console.WriteLine("-----------------------------------------  Update Teacher  --------------------------------------------\n");

                Console.WriteLine("             1-First Name                 2-Last Name                 3-Email         \n");
                Console.WriteLine("             4-Password                   5-Qualification             6-Expertise     \n");
                Console.WriteLine("             0-Back                                                                   \n");

                Console.WriteLine("---------------------------------------------------------------------------------------------------------");

                int updateOption = Convert.ToInt32(Console.ReadLine());
                switch (updateOption)
                {
                    case 1:
                        Console.Write("New First Name :");
                        string fname = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(TeacherController.UpdateFirstName(id, fname));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White; break;
                    case 2:
                        Console.Write("New Last Name : ");
                        string lname = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(TeacherController.UpdateLastName(id, lname));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 3:
                        Console.Write("New Email : ");
                        string email = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(AdminController.UpdateEmail(id, email));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 4:
                        Console.Write("New Password : ");
                        string password = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(AdminController.UpdatePassword(id, password));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 5:
                        EQual qual = TeacherValidation.ValidateQualification();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(TeacherController.UpdateQualification(id, qual));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 6:
                        ECourse expertise = TeacherValidation.ValidateExpertise();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(TeacherController.UpdateExpertise(id, expertise));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 0:
                        Flag2 = false;
                        break;
                    default:
                        Console.WriteLine("-----------------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("                                    Wrong Choice   !!!   ");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("-----------------------------------------------------------------------------------------------");
                        Flag2 = false;
                        break;
                }
            }
        }


    }
}
