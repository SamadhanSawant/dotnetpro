﻿using System;
using Student_Management_System.Models;
using Student_Management_System.Controllers;
using Student_Management_System.Validations;
using Student_Management_System.Enum;

namespace Student_Management_System.ConsoleView
{
    public class StudentView
    {
        //student role
        //view details
        //update details

        public static void StudentRole(User user)
        {
            Console.Clear();
        TOP:
            Program.DisplayProjectName();
             Program.DisplayWelcome("Student");
          //  Program.DisplayWelcome("    " + u.FirstName + "  " + u.LastName + "      ");


            Boolean flag = true;
            while (flag)
            {
                
                Console.WriteLine("=================================== Student Dashboard  =======================================\n");

                Console.WriteLine("  1- Show Details      2- Update Password       3- Update Course       4- Update Mobile No    \n");

                Console.WriteLine("  0- Logout\n");

                Console.WriteLine("=============================================================================================\n");


                switch (Convert.ToInt32(Console.ReadLine()))
                {
                    case 1:
                        Console.WriteLine("========================================    Profile   =======================================\n");
                        StudentController.ShowDetails(user);
                        break;
                    case 2:
                        Console.WriteLine("----------------------------------------- Update Password --------------------------------------------");
                        String password = UserValidation.ValidatePassword();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(AdminController.UpdatePassword(user.UserId, password));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;

                    case 3:
                        Console.WriteLine("----------------------------------------- Update Course ----------------------------------------------");
                        ECourse course = StudentValidation.ValidateCourse();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(StudentController.UpdateCourse(user.UserId, course));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;

                    case 4:
                        Console.WriteLine("----------------------------------------- Update Mobile No -------------------------------------------");
                        string mobile = StudentValidation.ValidateMobileNo();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(StudentController.UpdateMobileNo(user.UserId, mobile));
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;

                    case 0:
                        Console.Clear();
                        Console.WriteLine("-----------------------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("                                        Logout  !!!");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("-----------------------------------------------------------------------------------------------------");
                        flag = false;
                        break;

                    default:
                        Console.Clear();
                        Console.WriteLine("-----------------------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        UserView.returnError("                                   Wrong Choice !!!");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("----------------------------------------------------------------------------------------------------");
                        goto TOP;
                }
            }
        }
    }
}
