﻿using Student_Management_System.Models;
using Microsoft.EntityFrameworkCore;


namespace Student_Management_System.DataBaseContext
{
    class SmsDbContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=SAMADHANS-VD\SQL2017; DataBase=DOTNET-G10; User Id=sa; Password=cybage@123456;");
        }

        public virtual DbSet<User> Users { get; set; }

        public virtual DbSet<Admin> Admins { get; set; }

        public virtual DbSet<Student> Students { get; set; }

        public virtual DbSet<Course> Courses { get; set; }

        public virtual DbSet<Teacher> Teachers { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasOne(x => x.admin).WithOne(i => i.user).HasForeignKey<Admin>(x => x.AdminId);
            modelBuilder.Entity<User>().HasOne(x => x.student).WithOne(i => i.user).HasForeignKey<Student>(x => x.StudentId);
            modelBuilder.Entity<User>().HasOne(x => x.teacher).WithOne(i => i.user).HasForeignKey<Teacher>(x => x.TeacherId);
            modelBuilder.Entity<Student>().HasOne(x => x.course1).WithOne(i => i.student).HasForeignKey<Course>(x => x.CourseId);
        }
    }
}
