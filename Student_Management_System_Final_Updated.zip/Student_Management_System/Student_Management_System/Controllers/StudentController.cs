﻿using System;
using Student_Management_System.DataBaseContext;
using Student_Management_System.Models;
using Student_Management_System.Enum;
using System.Linq;

namespace Student_Management_System.Controllers
{
    public class StudentController
    {

        public static string UpdateFirstName(int id, string name)
        {
            SmsDbContext ctx = new();
            Student stud = ctx.Students.Find(id);
            Student stud2 = stud;
            stud.FirstName = name;
            ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
         //   Console.ForegroundColor = ConsoleColor.Green;
                                               return stud2.FirstName + " first name updated as " + stud.FirstName;
         //   Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        }


        public static string UpdateLastName(int id, string name)
        {
            SmsDbContext ctx = new();
            Student stud = ctx.Students.Find(id);
            Student stud2 = stud;
            stud.LastName = name;
            ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        //      Console.ForegroundColor = ConsoleColor.Green;
                                                 return stud2.LastName + " last name updated as " + stud.LastName;
        //    Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        }


        public static string UpdateMobileNo(int id, string mobile)
        {
            SmsDbContext ctx = new();
            Student stud = ctx.Students.Find(id);
            Student stud2 = stud;
            stud.MobileNo = mobile;
            ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        //    Console.ForegroundColor = ConsoleColor.Green;
                                          return "Mobile no is changed to " + stud.MobileNo;
        //    Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        }

        public static void ShowDetails(User u)
        {
            SmsDbContext ctx = new SmsDbContext();
            Student s = ctx.Students.Find(u.UserId);
            Course c = ctx.Courses.Find(u.UserId);

            Console.WriteLine(String.Format("|{0,10}|{1,15}|{2,15}|{3,20}|{4,10}|{5,10}|{6,8}|{7,8}|{8,11}|", "Student Id", "FirstName", "LastName", "Email ID", "Password", "Course", "Gender", "Country", "MobileNo"));
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
            Console.WriteLine(String.Format("|{0,10}|{1,15}|{2,15}|{3,20}|{4,10}|{5,10}|{6,8}|{7,8}|{8,11}|", s.StudentId, s.FirstName, s.LastName, u.Email, u.Password, c.course, s.Gender, s.Country, s.MobileNo));
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");

        }

        internal static string UpdateCountry(int id, string country)
        {
            SmsDbContext ctx = new();
            Student stud = ctx.Students.Find(id);
            Student stud2 = stud;
            stud.Country = country;
            ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
         //    Console.ForegroundColor = ConsoleColor.Green;
                                                         return "Country Updated !!!";
        //    Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        }

        internal static string UpdateCourse(int id, ECourse course)
        {
            SmsDbContext ctx = new();
            Student s = ctx.Students.Find(id);
            Course c = ctx.Courses.Find(id);
            Student stud = s;
            c.course = course;
            s.course1 = c;
            ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
         //   Console.ForegroundColor = ConsoleColor.Green;
                                                      return "Course Updated !!!";
         //   Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        }

    }
}
