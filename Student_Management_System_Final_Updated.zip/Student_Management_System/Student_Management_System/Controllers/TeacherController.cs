﻿using System;
using Student_Management_System.DataBaseContext;
using Student_Management_System.Models;
using Student_Management_System.Enum;

namespace Student_Management_System.Controllers
{
    public class TeacherController
    {
        public static EQual SelectQual()
        {
        HERE:
            EQual SelectedQual;

            switch (Convert.ToInt32(Console.ReadLine()))
            {
                case 1: SelectedQual = EQual.Bachelor; break;
                case 2: SelectedQual = EQual.Master; break;
                case 3: SelectedQual = EQual.PHD; break;
                default:
                    Console.WriteLine("-----------------------------------------------------------------------------------------------");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("                                    Wrong Choice   !!!   ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("-----------------------------------------------------------------------------------------------");

                    goto HERE;
            }

            return SelectedQual;
        }

        public static ECourse SelectExpertise()
        {
        HERE:
            ECourse SelectedCourse;

            switch (Convert.ToInt32(Console.ReadLine()))
            {
                case 1: SelectedCourse = ECourse.ANGULAR; break;
                case 2: SelectedCourse = ECourse.DOTNET; break;
                case 3: SelectedCourse = ECourse.JAVA; break;
                case 4: SelectedCourse = ECourse.REACT; break;
                default:
                    Console.WriteLine("-----------------------------------------------------------------------------------------------");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("                                    Wrong Choice   !!!   ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("-----------------------------------------------------------------------------------------------");

                    goto HERE;
            }

            return SelectedCourse;
        }

        public static void ShowDetails(User user)
        {
            SmsDbContext ctx = new SmsDbContext();
            Teacher t = ctx.Teachers.Find(user.UserId);
            User u = ctx.Users.Find(user.UserId);

            Console.WriteLine(String.Format("|{0,10}|{1,15}|{2,15}|{3,20}|{4,10}|{5,15}|", "Teacher Id", "FirstName", "LastName", "Email ID", "Expertise", "Qualification"));
            Console.WriteLine("-----------------------------------------------------------------------------------------------");
            Console.WriteLine(String.Format("|{0,10}|{1,15}|{2,15}|{3,20}|{4,10}|{5,15}|", t.TeacherId, t.FirstName, t.LastName, u.Email, t.Expertise, t.Qualification));
            Console.WriteLine("-----------------------------------------------------------------------------------------------");
        }

        public static string UpdateFirstName(int id, string fname)
        {
            SmsDbContext ctx = new();
            Teacher t = ctx.Teachers.Find(id);
            t.FirstName = fname;
            ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
                                                   return " first name updated as " + t.FirstName;
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        }

        public static string UpdateLastName(int id, string lname)
        {
            SmsDbContext ctx = new();
            Teacher t = ctx.Teachers.Find(id);
            t.LastName = lname;
            ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
                                                   return " last name updated as " + t.LastName;
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        }

        public static string UpdateQualification(int id, EQual qual)
        {
            SmsDbContext ctx = new();
            Teacher t = ctx.Teachers.Find(id);

            t.Qualification = qual;
            ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
                                                      return "Qualification Updated !!!";
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        }

        public static string UpdateExpertise(int id, ECourse expertise)
        {
            SmsDbContext ctx = new();
            Teacher t = ctx.Teachers.Find(id);

            t.Expertise = expertise;
            ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
                                                      return "Expertise Updated !!!";
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        }
    }

}

