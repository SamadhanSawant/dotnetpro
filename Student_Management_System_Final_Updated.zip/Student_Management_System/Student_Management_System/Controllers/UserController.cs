﻿using System;
using System.Collections.Generic;
using System.Linq;
using Student_Management_System.Models;
using Student_Management_System.DataBaseContext;
using Student_Management_System.Enum;
using Student_Management_System.ConsoleView;

namespace Student_Management_System.Controllers
{

    class UserController
    {
        //getuser
        //register student
        //register teacher

        public static User getUser(string email, string password)
        {
            SmsDbContext ctx = new SmsDbContext();
            List<User> UserList = ctx.Users.ToList();
            User user = new User();

            foreach (var u in UserList)
            {
                if (u.Email == email && u.Password == password)
                {
                    user = u;
                }
            }

            return user;
        }


        public static string RegisterTeacher(string fname, string lname, string email, string password, EQual qual, ECourse expertise)
        {
            SmsDbContext ctx = new SmsDbContext();
            Teacher t = new Teacher();
            User u = new User();

            t.FirstName = fname;
            t.LastName = lname;
            t.Qualification = qual;
            t.Expertise = expertise;
            u.Email = email;
            u.Password = password;
            u.Role = ERole.TEACHER;
            u.teacher = t;
            ctx.Teachers.Add(t);
            ctx.Users.Add(u);
            ctx.SaveChanges();

            return fname;
        }


        internal static string RegisterStudent(string fname, string lname, string email, string password, ECourse course, string gender, string country, string mobile)
        {
            SmsDbContext ctx = new SmsDbContext();
            Course c = new Course();
            Student s = new Student();
            User u = new User();

            s.FirstName = fname;
            s.LastName = lname;
            u.Email = email;
            u.Password = password;
            u.Role = ERole.STUDENT;
            c.course = course;
            s.Gender = gender;
            s.Country = country;
            s.MobileNo = mobile;
            s.course1 = c;
            u.student = s;
            ctx.Courses.Add(c);
            ctx.Students.Add(s);
            ctx.Users.Add(u);
            ctx.SaveChanges();

            return fname;
        }
    }

}