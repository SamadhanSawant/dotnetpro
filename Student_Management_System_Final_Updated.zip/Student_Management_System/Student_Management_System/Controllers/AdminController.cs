﻿using Student_Management_System.DataBaseContext;
using Student_Management_System.Models;
using Student_Management_System.Enum;
using System.Collections.Generic;
using System;
using System.Linq;

namespace Student_Management_System.Controllers
{
    class AdminController
    {

        public static void ShowAllStudents()
        {
            SmsDbContext ctx = new SmsDbContext();

            List<User> UserList = ctx.Users.ToList();
            List<Student> StudentList = ctx.Students.ToList();
            List<Course> CourseList = ctx.Courses.ToList();

            Console.WriteLine(String.Format("|{0,10}|{1,15}|{2,15}|{3,20}|{4,10}|{5,8}|{6,8}|{7,11}|", "Student Id", "FirstName", "LastName", "Email ID", "course", "Gender", "Country", "MobileNo"));

            foreach (var u in UserList)
            {
                foreach (var s in StudentList)
                {
                    foreach (var c in CourseList)
                    {
                        if (u.UserId == s.StudentId && s.StudentId == c.CourseId)
                        {

                            Console.WriteLine(String.Format("|{0,10}|{1,15}|{2,15}|{3,20}|{4,10}|{5,8}|{6,8}|{7,11}|", s.StudentId, s.FirstName, s.LastName, u.Email, c.course, s.Gender, s.Country, s.MobileNo));

                        }
                    }
                }
            }

        }


        public static void ShowAllTeachers()
        {
            SmsDbContext ctx = new SmsDbContext();

            List<User> UserList = ctx.Users.ToList();
            List<Teacher> TeacherList = ctx.Teachers.ToList();

            Console.WriteLine(String.Format("|{0,10}|{1,15}|{2,15}|{3,20}|{4,18}|{5,15}|", "Teacher Id", "FirstName", "LastName", "Email ID", "Qualification", "Expertise"));

          
            foreach (var u in UserList)
            {
                foreach (var t in TeacherList)
                {
                    if (u.UserId == t.TeacherId)
                    {
                      
                        Console.WriteLine(String.Format("|{0,10}|{1,15}|{2,15}|{3,20}|{4,18}|{5,15}|", t.TeacherId, t.FirstName, t.LastName, u.Email, t.Qualification, t.Expertise));
                       
                    }
                }
            }
             Console.WriteLine();
        }


        public static string DeleteStudent(int id)
        {
            SmsDbContext ctx = new();
            Student s = ctx.Students.Find(id);
            User u = ctx.Users.Find(id);
            ctx.Students.Remove(s);
            ctx.Users.Remove(u);
            ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
          //  Console.ForegroundColor = ConsoleColor.Green;
                                                   return s.FirstName + "  Student  Deleted  ";
          //  Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");

        }


        public static string DeleteTeacher(int id)
        {
            SmsDbContext ctx = new();
            Teacher t = ctx.Teachers.Find(id);
            User u = ctx.Users.Find(id);
            ctx.Teachers.Remove(t);
            ctx.Users.Remove(u);
            ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
            //Console.ForegroundColor = ConsoleColor.Green;
           // Console.WriteLine(               t.FirstName + "  Teacher  Deleted  ");
           // Console.ForegroundColor = ConsoleColor.White;
                                                  return t.FirstName + "  Teacher  Deleted  ";
          
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");

        }


        public static string UpdateEmail(int id, String email)
        {
            SmsDbContext ctx = new SmsDbContext();
            User u = ctx.Users.Find(id);
            u.Email = email;
            ctx.Users.Update(u);
            int x = ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
          //  Console.ForegroundColor = ConsoleColor.Green;
                                                   return "New Email updated !!!";
           // Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        }


        public static string UpdatePassword(int id, String password)
        {
            SmsDbContext ctx = new();
            User u = ctx.Users.Find(id);
            u.Password = password;
            ctx.Users.Update(u);
            ctx.SaveChanges();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
         //   Console.ForegroundColor = ConsoleColor.Green;
                                                  return "New Password Updated !!!";
         //   Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("----------------------------------------------------------------------------------------------------------");
        }


        public static void AddAdmin()
        {
            SmsDbContext ctx = new SmsDbContext();
            Admin a = new Admin();
            User u = new User();
            a.Name = "admin";
            u.Email = "admin@gmail.com";
            u.Password = "12345";
            u.Role = ERole.ADMIN;
            u.admin = a;
            ctx.Admins.Add(a);
            ctx.Users.Add(u);
            ctx.SaveChanges();
        }

    }
}