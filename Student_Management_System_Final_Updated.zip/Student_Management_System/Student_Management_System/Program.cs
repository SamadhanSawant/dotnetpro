﻿using System;
using Student_Management_System.ConsoleView;
using Student_Management_System.Controllers;

namespace Student_Management_System
{
    class Program
    {
        static void Main(string[] args)
        {
         //AdminController.AddAdmin();
        start:
            while (true)
            {  
                
                DisplayProjectName();
                Console.WriteLine("================================================================================================");
                Console.WriteLine(" 1 - Login       2 - Student Registration       3 - Teacher Registration          0 - Refresh");
                Console.WriteLine("================================================================================================");
                Console.Write(" >>  ");
                switch (Convert.ToInt32(Console.ReadLine()))
                {
                    case 1:
                        UserView.Login();
                        break;

                    case 2:
                        Console.WriteLine("----------------------------------- Student's Registration ------------------------------------\n");
                        UserView.StudentRegistration();
                        goBack();
                        break;

                    case 3:
                        Console.WriteLine("----------------------------------- Teacher's Registration ------------------------------------\n");
                        UserView.TeacherRegistration();
                        goBack();
                        break;

                    case 0:
                        goto start;

                    default:
                        Console.WriteLine("-----------------------------------------------------------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("                                    Wrong Choice   !!!   ");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("-----------------------------------------------------------------------------------------------");
                        break;
                }
            }
        }

        private static void goBack()
        {
            Console.Write(" Enter 0 to go Back \n >>");

            if (Console.ReadLine() != "0") goBack();
        }

        public static void DisplayProjectName()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            string title = @"
 _____  _               _               _    ___  ___                                                           _     _____              _                    
/  ___|| |             | |             | |   |  \/  |                                                          | |   /  ___|            | |                   
\ `--. | |_  _   _   __| |  ___  _ __  | |_  | .  . |  __ _  _ __    __ _   __ _   ___  _ __ ___    ___  _ __  | |_  \ `--.  _   _  ___ | |_   ___  _ __ ___  
 `--. \| __|| | | | / _` | / _ \| '_ \ | __| | |\/| | / _` || '_ \  / _` | / _` | / _ \| '_ ` _ \  / _ \| '_ \ | __|  `--. \| | | |/ __|| __| / _ \| '_ ` _ \ 
/\__/ /| |_ | |_| || (_| ||  __/| | | || |_  | |  | || (_| || | | || (_| || (_| ||  __/| | | | | ||  __/| | | || |_  /\__/ /| |_| |\__ \| |_ |  __/| | | | | |
\____/  \__| \__,_| \__,_| \___||_| |_| \__| \_|  |_/ \__,_||_| |_| \__,_| \__, | \___||_| |_| |_| \___||_| |_| \__| \____/  \__, ||___/ \__| \___||_| |_| |_|
                                                                            __/ |                                             __/ |                           
                                                                           |___/                                             |___/                            
";
            Console.Clear();
            Console.WriteLine(title);
            Console.ResetColor();
        }

        public static void DisplayWelcome(String user)
        {
            Console.WriteLine("==============================================================================================");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("                                Welcome " + user + " !!!             ");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("==============================================================================================");
        }


    }
}

/*
 
            AdminController.AddAdmin();

*/
