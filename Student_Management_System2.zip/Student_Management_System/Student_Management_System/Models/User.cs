﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Student_Management_System.Enum;

namespace Student_Management_System.Models
{
    public class User
    {
        [Key]
        public int userId { get; set; }

        [Column("Name")]
        [Required(ErrorMessage = "Please enter Name")]
        [MaxLength(10)]
        public string name { get; set; }

        [Column("Email")]
        [Required(ErrorMessage = "Please enter Email ID")]
        [MaxLength(20)]
        public string email { get; set; }

        [Column("Password")]
        [Required(ErrorMessage = "Please Enter Password")]
        [MaxLength(12)]
        public string password { get; set; }

        [Column("Role")]
        [Required(ErrorMessage = "Please Enter your Role")]
        public Role role { get; set; }

        public virtual Student student { get; set; }

    }

}

