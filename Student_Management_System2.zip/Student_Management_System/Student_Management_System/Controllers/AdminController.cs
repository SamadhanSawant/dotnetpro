﻿using Student_Management_System.DataBaseContext;
using Student_Management_System.Models;
using Student_Management_System.Enum;
using Student_Management_System.ConsoleView;
using System.Collections.Generic;
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Student_Management_System.Controllers
{
    class AdminController
    {
        SmsDbContext ctx = new SmsDbContext();

        public static void ShowAll()
        {
            SmsDbContext ctx = new SmsDbContext();
            List<User> usrs = ctx.Users.ToList();
            List<Student> stds = ctx.Students.ToList();
            List<Course> courses = ctx.Courses.ToList();

            foreach (User u in usrs)
            {
                foreach (Student s in stds)
                {
                    foreach (Course c in courses)
                    {
                        if (s.studentId == u.userId && c.courseId == s.studentId)
                        {
                            Console.WriteLine($"{u.userId}  {u.name}  {u.email}  {u.password}   {u.role}  {c.courseName}");
                        }
                    }

                }
            }
        }

        public static String deleteStudent(int id)
           {
               SmsDbContext ctx = new();
               User usr = ctx.Users.Find(id);
               Student stud = ctx.Students.Find(id);
               Course course = ctx.Courses.Find(id);

                ctx.Courses.Remove(course);
                ctx.Students.Remove(stud);
                ctx.Users.Remove(usr);
               ctx.SaveChanges();

               return usr.name + "  Student  Deleted  ";
               
           }

        public static String AddStudent(String name, String email, String password, String course)
        {

            SmsDbContext ctx = new SmsDbContext();

            Course c = new Course();
            Student s = new Student();
            User u = new User();

            u.name = name;
            u.email = email;
            u.password = password;
            u.role = Role.STUDENT;
            c.courseName = "Angular";
            s.course = c;
            u.student = s;
            ctx.Courses.Add(c);
            ctx.Students.Add(s);
            ctx.Users.Add(u);

            ctx.SaveChanges();
            return name + " Added to SMS !!!";
        }

        public void AddAdmin()
        {
            SmsDbContext ctx = new SmsDbContext();
            User admn = new User();
            Student s = new Student();
            Course c = new Course();
            admn.name = "admin";
            admn.email = "admin@gmail.com";
            admn.password = "12345";
            admn.role = Role.ADMIN;
            c.courseName = "-";
            s.course = c;
            admn.student = s;
            ctx.Users.Add(admn);
            ctx.Students.Add(s);
            ctx.Courses.Add(c);
            ctx.SaveChanges();
        }

        public static String updateName(int id, String name)
        {
            SmsDbContext ctx = new();
            User usr = ctx.Users.Find(id);
            Student stud = ctx.Students.Find(id);
            usr.name = name;
            ctx.Users.Update(usr);
            int x = ctx.SaveChanges();
            return "x";
        }

        public static String updateEmail(int id,String email)
        {
            SmsDbContext ctx = new();
            User usr = ctx.Users.Find(id);
            usr.email = email;
            ctx.Users.Update(usr);
            int x = ctx.SaveChanges();
            return "x";
        }

        public static String updatePassword(int id, String password)
        {
            SmsDbContext ctx = new();
            User usr = ctx.Users.Find(id);
            usr.password = password;
            ctx.Users.Update(usr);
            int x = ctx.SaveChanges();
            return "x";
        }

        public static String updateCourse(int id, String course)
        {
            SmsDbContext ctx = new();
            User u = ctx.Users.Find(id);
            Student s = ctx.Students.Find(id);
            Course c = ctx.Courses.Find(id);
            c.courseName = course;
            s.course = c;
            u.student = s;
            ctx.Courses.Update(c);
            ctx.Students.Update(s);
            ctx.Users.Update(u);
            int x = ctx.SaveChanges();
            return "x";
        }
    }
}