﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Student_Management_System.DataBaseContext;
using Student_Management_System.Models;

namespace Student_Management_System.Controllers
{
    public class StudentController
    {
        internal static String ShowDetails(User user)
        {
            SmsDbContext dbctx = new SmsDbContext();

            Student student = dbctx.Students.Find(user.userId);
            Course course = dbctx.Courses.Find(student.studentId);

            return $"{user.userId}  {user.name}  {user.email}  {user.password}   {user.role}  {course.courseName}";
        }
    }

}
