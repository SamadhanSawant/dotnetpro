﻿using System;
using System.Collections.Generic;
using System.Linq;
using Student_Management_System.Models;
using Student_Management_System.DataBaseContext;
using Student_Management_System.Enum;
using Student_Management_System.ConsoleView;
using System.Text.RegularExpressions;

namespace Student_Management_System.Controllers
{
    
    class UserController
    {
        SmsDbContext ctx = new SmsDbContext();
        StudentView studentView = new StudentView();

        public String UserLogin(String email, String password)
        {
            var users = ctx.Users.Where(x => x.email == email && x.password == password);
            User searchedUser = new User();
            foreach (User u in users)
            {
                if (u.email == email && u.password == password)  searchedUser = u;
            }
            if (searchedUser != null)
            {
                if (searchedUser.role == Role.STUDENT)
                {
                    studentView.StudentRole(searchedUser);
                    return "Logged in as Student"; 
                }
                else if (searchedUser.role == Role.ADMIN) {
                    AdminView.AdminRole();
                    return "Logged in as Admin";
                }
                else return "Invalid Credentials !!!";
            }
            else return "User Not Found !!!";
        }

        public String userRegistration(String name, String email, String password, String course)
        {
           




            User u = new User();
            Student s = new Student();
            Course c = new Course();

            u.name = name;
            u.email = email;
            u.password = password;
            u.role = Role.STUDENT;
            c.courseName = course;
            s.course = c;
            u.student = s;
            ctx.Users.Add(u);
            ctx.Students.Add(s);
            ctx.SaveChanges();
            
            return name + " registered !!!";
        }

    }
    
}