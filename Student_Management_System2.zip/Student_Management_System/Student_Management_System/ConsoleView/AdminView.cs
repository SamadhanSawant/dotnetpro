﻿using Student_Management_System.DataBaseContext;
using Student_Management_System.Models;
using Student_Management_System.Controllers;
using System.Collections.Generic;
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Student_Management_System.ConsoleView
{
    class AdminView
    {
        public static void AdminRole()
        {
            Console.WriteLine("--------------------");
            Console.WriteLine("  Welcome Admin !!! ");
            Console.WriteLine("--------------------");
            Boolean flag = true;
            while (flag)
            {
                Console.WriteLine("1-Add_Student\n2-Update_Student\n3-Remove_Student\n4-Show_All_Students\n0-Logout");
                Console.WriteLine("-----------------------------");

                int option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1: AddStudentForm(); break;
                    case 2: Console.WriteLine("------ Update Student ------");
                            Console.Write("Enter ID :");
                            int id1 = Convert.ToInt32(Console.ReadLine());
                            updateStudentForm(id1); break;
                    case 3: Console.WriteLine("------ Delete Student ------");
                            Console.Write("Enter ID :");
                            int id2 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine(AdminController.deleteStudent(id2)); break;
                    case 4: Console.WriteLine("--------- All Users Data ---------");
                            AdminController.ShowAll(); break;
    
                    case 5:
                        Console.WriteLine("Logout !!!");
                        flag = false;
                        break;
                    default: Console.WriteLine("Wrong Choice !!!"); break;
                }
            }
        }

        public static void AddStudentForm()
        {
            Console.WriteLine("------- Add Student ------");
            Console.Write("Name : ");
            String name = Console.ReadLine();
            Console.Write("Email : ");
            String email = Console.ReadLine();
            Console.Write("Password : ");
            String password = Console.ReadLine();
            Console.Write("Course : ");
            String course = Console.ReadLine();
            Console.WriteLine("--------------------------"); 
            Console.WriteLine(AdminController.AddStudent(name,email,password,course));

        }

        private static void updateStudentForm(int id)
        {
            Boolean Flag2 = true;
            while (Flag2)
            {
                Console.WriteLine("1-Update_Name\n2-Update_Email\n3-Update_Password\n4-Update_Course\n5-Back");
                Console.WriteLine("-----------------------------");
                int updateOption = Convert.ToInt32(Console.ReadLine());
                switch (updateOption)
                {
                    case 1:
                        Console.Write("New Name :");
                        String name = Console.ReadLine();
                        Console.WriteLine(AdminController.updateName(id,name)); break;
                    case 2:
                        Console.Write("New Email :");
                        String email = Console.ReadLine();
                        Console.WriteLine(AdminController.updateEmail(id,email)); break;
                    case 3:
                        Console.Write("New Password :");
                        String password = Console.ReadLine();
                        Console.WriteLine(AdminController.updatePassword(id,password)); break;
                    case 4:
                        Console.Write("New Course :");
                        String course = Console.ReadLine();
                        Console.WriteLine(AdminController.updateCourse(id,course)); break;
                    case 5: Flag2 = false; break;
                    default: Console.WriteLine("Wrong Choice !!!"); break;
                }
            }
        }
    }
}
