﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Student_Management_System.DataBaseContext;
using Student_Management_System.Models;
using Student_Management_System.Controllers;

namespace Student_Management_System.ConsoleView
{
    public class StudentView 
    { 
        public void StudentRole(User user)
        {
            Console.WriteLine("-----------------------------");
            Console.WriteLine("  Welcome "+user.name+" !!! ");
            Console.WriteLine("-----------------------------");
            Boolean flag = true;
            while (flag)
            {
                Console.WriteLine("1-View_Profile \n2-Update_Profile \n0-Logout");
                Console.WriteLine("-----------------------------");

                int option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    
                    case 1: Console.WriteLine(StudentController.ShowDetails(user)); break;
                    case 2: UpdateStudent(user.userId); break;
                    case 0:
                        Console.WriteLine("Logout !!!");
                        Console.WriteLine("==============================");
                        flag = false;
                        break;
                    default: Console.WriteLine("Wrong Choice !!!"); break;
                }
            }
        }

        private static void UpdateStudent(int userId)
        {
            Boolean exit=true;

            while (exit)
            {
                Console.WriteLine("1-Update_Name\n2-Update_Email\n3-Update_Password\n4-Update_Course\n0-Back");
                Console.WriteLine("-----------------------------");
                int updateOption = Convert.ToInt32(Console.ReadLine());
                switch (updateOption)
                {
                    case 1:
                        Console.Write("New Name :");
                        String name = Console.ReadLine();
                        Console.WriteLine(AdminController.updateName(userId, name)); break;
                    case 2:
                        Console.Write("New Email :");
                        String email = Console.ReadLine();
                        Console.WriteLine(AdminController.updateEmail(userId, email)); break;
                    case 3:
                        Console.Write("New Password :");
                        String password = Console.ReadLine();
                        Console.WriteLine(AdminController.updatePassword(userId, password)); break;
                    case 4:
                        Console.Write("New Course :");
                        String course = Console.ReadLine();
                        Console.WriteLine(AdminController.updateCourse(userId, course)); break;
                    case 0: exit=false;  break;
                    default: Console.WriteLine("Wrong Choice !!!"); break;
                }
            }
        }
    }

}
