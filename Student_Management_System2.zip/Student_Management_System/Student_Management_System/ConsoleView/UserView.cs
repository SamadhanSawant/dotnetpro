﻿using Microsoft.IdentityModel.Tokens;
using Student_Management_System.Controllers;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace Student_Management_System.ConsoleView
{
    public class UserView
    {
      

        UserController userControl = new UserController();

        string name = "";
        string email = "";
        string password = "";
        //string password1 = "";

       



        public void LoginForm()
        {     
            Console.WriteLine("-------User's Login -------");

            Console.Write("Email : ");
            string email = Console.ReadLine();
            Console.Write("Password : ");
            Console.ForegroundColor = ConsoleColor.Black;
            string password = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("---------------------------");

            Console.WriteLine("---------------------------");
            Console.WriteLine(userControl.UserLogin(email, password));
            Console.WriteLine("---------------------------");

           

        }

        public void RegistrationForm()
        {

            Console.WriteLine("------- Student's Registration ------");

            ValidateName();

            void ValidateName()
            {

                Console.Write("First Name: ");

                name = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(name) || name.All(char.IsDigit))
                {
                    Console.WriteLine("Please enter valid name");
                    ValidateName();
                }

            }

            //Console.Write("Name : ");
            //String studentName = Console.ReadLine();

            InputEmail();
            void InputEmail()
            {
                Console.Write("Email id: ");

                email = Console.ReadLine();




                string pattern = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";


                //if (Regex.IsMatch(email, pattern))

                //if email is invalid
                if (!Regex.IsMatch(email, pattern))
                {
                    Console.WriteLine(email + " not a valid Email address. Please enter correct email \n ");
                    InputEmail();
                }

            }

            //PasswordMasking();

            // void PasswordMasking()
            //{
            //    string password = "";

            //    Console.Write("Password: ");

            //    ConsoleKeyInfo key;
            //    do
            //    {

            //        key = Console.ReadKey(true);
            //        if (key.Key != ConsoleKey.Backspace) // Backspace Should Not Work
            //        {

            //            password += key.KeyChar;
            //         //   Console.ForegroundColor = ConsoleColor.Black;
            //            Console.Write("*");
            //         //   Console.ForegroundColor = ConsoleColor.White;
            //        }

            //        else
            //        {
            //            Console.Write("\b");
            //        }
            //    } 
            //    while (key.Key != ConsoleKey.Enter); // Stops Receving Keys Once Enter is Pressed

            //    if (string.IsNullOrWhiteSpace(password) || password.Length < 8)
            //    {
            //        Console.WriteLine("\nPlease enter password with length > 8");
            //        PasswordMasking();
            //    }

            //}


            validatePassword();
            void validatePassword()
            {
               
                Console.Write("Password: ");     
                Console.ForegroundColor = ConsoleColor.Black;
                string password = Console.ReadLine();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Confirm Password: ");
                Console.ForegroundColor = ConsoleColor.Black;
                string password1 = Console.ReadLine();
                Console.ForegroundColor = ConsoleColor.White;


                Console.ForegroundColor = ConsoleColor.White;

                if (string.IsNullOrWhiteSpace(password) || password.Length < 8)
                {
                    Console.WriteLine("\n Please enter password with length.");
                    validatePassword();
                }





                //  PasswordMasking1();

                //void PasswordMasking1()
                //{
                //    string password1 = "";

                //    Console.Write("Confirm Password: ");

                //    ConsoleKeyInfo key;
                //    do
                //    {

                //        key = Console.ReadKey(true);
                //        if (key.Key != ConsoleKey.Clear) // Backspace Should Not Work
                //        {

                //            password1 += key.KeyChar;
                //           // Console.ForegroundColor = ConsoleColor.Black;
                //            Console.Write("*");
                //          //  Console.ForegroundColor = ConsoleColor.White;
                //        }

                //        else
                //        {
                //            Console.Write("\b");
                //        }
                //    } while (key.Key != ConsoleKey.Enter); // Stops Receving Keys Once Enter is Pressed

                //    if (string.IsNullOrWhiteSpace(password1) || password1.Length < 8)
                //    {
                //        Console.WriteLine("\nPlease enter password with length > 8");
                //        PasswordMasking1();
                //    }

                //}
                //Console.WriteLine();


                if (password == password1 )
                {
                    Console.WriteLine("------------------------------------------");
                    Console.WriteLine("password matched!!!");
                    Console.WriteLine("------------------------------------------");

                }
                else if (password != password1)
                {
                    Console.WriteLine("------------------------------------------");
                    Console.WriteLine("password doesnt match !!!");
                    Console.WriteLine("------------------------------------------");

                }

                // Console.Write("First Name : ");
                //   String name = Console.ReadLine();
                //    Console.Write("Email : ");
                //  String email = Console.ReadLine();
                //   Console.Write("Password : ");
                //    String password = Console.ReadLine();
                Console.Write("Course: ");
               String course = Console.ReadLine();



                Console.WriteLine("------------------------------------------");
                Console.WriteLine(userControl.userRegistration(name, email, password, course));
                Console.WriteLine("------------------------------------------");


            }
    }
    
}