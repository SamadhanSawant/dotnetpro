﻿namespace Student_Management_System.Enum
{
    public enum Role
    {
        ADMIN,STUDENT,TEACHER
    }
}
