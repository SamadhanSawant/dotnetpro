﻿using System;
using Student_Management_System.Controllers;
using Student_Management_System.ConsoleView;

namespace Student_Management_System
{
    class Program
    {

        //AdminController admn = new AdminController();
        //admn.AddAdmin();
        static void Main(string[] args)
        {
                    startpoint:
            Console.Clear();
            Console.WriteLine("==========================================");
            Console.WriteLine("|   Welcome to SMS by Project Group 10   |");
            Console.WriteLine("==========================================");

       
            while(true)
            {
                Console.WriteLine(" 1-Login \n 2-Registration \n 0-Refresh");
                Console.WriteLine("==========================================");

                int option = Convert.ToInt32(Console.ReadLine());

                UserView userview = new UserView();
                
                 switch (option)
                 {
                    case 1:
                        userview.LoginForm();
                        break;

                    case 2:
                         userview.RegistrationForm();
                         break;

                     case 0:
                         goto startpoint;

                     default:
                         Console.WriteLine("----------------------");
                         Console.WriteLine("    Wrong Choice!!!   ");
                         Console.WriteLine("----------------------");
                         break;
                 }
            }

        }
    }
}
/*
 


*/
